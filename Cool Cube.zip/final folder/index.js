
var d;

function setup(){
  createCanvas(windowWidth,windowHeight, WEBGL);
  d = new CoolCube();
}
function draw(){
  d.draw();
}
document.addEventListener("DOMContentLoaded",function(){
	var ca = document.getElementById("colourA");
  var cb = document.getElementById("colourB");
  var cs = document.getElementById("mySize");
  var cr = document.getElementById("x");
  var rr = document.getElementById("chk");
  var cbg = document.getElementById("bgchk");
  function changeColour(event){
    let colourA = document.getElementById("colourA").value;
    let colourB = document.getElementById("colourB").value;
    d.setColours(colourA,colourB);
  }
  function changeSize(event){
    let sizeA = document.getElementById("mySize").value;
    d.setSize(sizeA);
  }
  function changeRotation(event){
    let Rotation = document.getElementById("x").value;
    d.setRotation(Rotation);
  }
  function rainbows(event){
    let rrr = document.getElementById("chk").checked;
    if (rrr == true) {d.setrainbowOn();
    } else {d.setrainbowOff();}
  }
  function changebg(event){
    let bgbg = document.getElementById("bgchk").checked;
    if (bgbg == true) {d.setbg(0);
    }else{
      d.setbg(1);
    }
  }
  
  ca.addEventListener("change", changeColour);
  cb.addEventListener("change", changeColour);
  cs.addEventListener("change", changeSize);
  cr.addEventListener("change", changeRotation);
  rr.addEventListener("change", rainbows);
  cbg.addEventListener("change",changebg);
  var cf = document.getElementById(colour_changeA);
  var cg = document.getElementById(colour_changeB);
  var css = document.getElementById(sizechange);
  var crr = document.getElementById(r);
  var rrr = document.getElementById(mycheck);
  var bgel = document.getElementById(bgcheck);
  
  cf.addEventListener("submit",function (event){
    event,preventDefault()});
  cg.addEventListener("submit",function (event){
    event,preventDefault()});
  css.addEventListener("submit",function (event){
    event,preventDefault()});
  crr.addEventListener("submit",function (event){
    event,preventDefault()});
  rrr.addEventListener("submit",function (event){
    event,preventDefault()});
  bgel.addEventListener("submit",function (event){
    event,preventDefault()});
})
