class CoolCube{
	constructor(size,rotation,colour1,colour2){
		this.size = size||100;
		this.a = size+1||101;
		this.rotate = Math.pow(4,rotation/100)/10000||10;
		this.c1 = colour1||'magenta';
		this.c2 = colour2||'lime';
    this.X = radians(45);
    this.Y = radians(145);
    this.x = 0.1;
    this.y = 0.1;
    this.z = 0.1;
		this.rainbow = 0;
		this.bg = 0;
}
	setrainbowOn(){
		this.rainbow = 1;
		}
	setrainbowOff(){
		this.rainbow = 0;
	}
	getrainbow(){
		return this.rainbow;
	}
	setbg(n){
		this.bg = n;
	}
	getbg(){
		return this.bg;
	}
	getSize(){
		return this.size;
	}
	setSize(size){
		this.size = size;
		this.a = size+1;
	}
	getColours(){
		return this.c1, this.c2;
	}
  setColours(colourA, colourB){
    this.c1 = colourA;
    this.c2 = colourB;
  }
  setRotate(X,Y){
    this.X = X||radians(45);
    this.Y = Y||radians(145);
  }
	getRotate(){
		return this.X, this.Y;
	}
  setTranslate(x,y,z){
    this.x = x;
    this.y = y;
    this.z = z;
  }
	getTranslate(){
		return this.x, this.y, this.z;
	}
	getRotation(){
		return this.rotate;
	}
	setRotation(rotate){
		this.rotate = Math.pow(4,rotate/100)/10000;
	}
	draw(){
		var maxFramecount = 75;
		var t = frameCount/maxFramecount;
		var theta = TWO_PI*t;
    orbitControl();
		if (this.bg==0) {background(0);}
		rotate(theta/this.rotate);
    translate(this.x,this.y,this.z);
		// lights
  	directionalLight(245, 245, 245, 300, -200, -200);  
  	ambientLight(240, 240, 240); 
  
  	// rotate the whole cube
  	rotateY(this.Y);
  	rotateX(this.X);
		
		// 3 nested for loops to create sides	
  	for (var x = -this.size; x <= this.size; x += 20) {
  	for (var y = -this.size; y <= this.size; y += 20) {
  	for (var z = -this.size; z <= this.size; z += 200) {

    // map size of small cubes with offset
    var offSet = ((x*y*z))/this.a;
    var sz = map(sin(-theta+offSet), -1, 1, -0, 20);
			
			var c1;
			var ran = 33*theta%360;
			var ran2 = (40*theta)%360;
			var c2;
			var rainbow = this.rainbow;
			if(rainbow == 1){
					colorMode(HSL);
					c1 = color(ran,100,50);
					c2 = color(ran2,100,50);
			} else {
			c1 = color(this.c1);
    	c2 = color(this.c2);
			}
   
  	if ((x*y*z)%24 == 0){
    	fill(c1);
    	stroke(c2);
  	} else {
    	fill(c2);
    	stroke(c1);
  	}
    
    	// small blocks, 3 times to create cube
    	shp(x,y,z,sz);
    	shp(y,z,x,sz);
    	shp(z,x,y,sz);

    	}}}
    function shp(x, y, z, d){
    
         push();
         translate(x,y,z);
         box(d);
         pop();
  }
	}
	
}